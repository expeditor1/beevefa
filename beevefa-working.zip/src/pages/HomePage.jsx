export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center text-center p-6">
      <h1 className="text-4xl font-bold text-blue-600">Welcome to Beevefa 🐝</h1>
      <p className="mt-4 text-gray-600">Your one-stop tourism experience.</p>
    </div>
  );
}