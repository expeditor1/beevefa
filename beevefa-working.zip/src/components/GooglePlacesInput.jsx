import { Autocomplete } from "@react-google-maps/api";
import { useRef } from "react";

export default function GooglePlacesInput({ onSelect }) {
  const autoCompleteRef = useRef(null);

  const handlePlaceChanged = () => {
    const place = autoCompleteRef.current.getPlace();
    if (place?.formatted_address) {
      onSelect(place.formatted_address);
    } else if (place?.name) {
      onSelect(place.name);
    }
  };

  return (
    <Autocomplete
      onLoad={(ref) => (autoCompleteRef.current = ref)}
      onPlaceChanged={handlePlaceChanged}
    >
      <input
        type="text"
        placeholder="Search a destination..."
        className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
      />
    </Autocomplete>
  );
}