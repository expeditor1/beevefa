import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { LoadScript } from "@react-google-maps/api";
import AuthPage from "./pages/AuthPage";
import MapSection from "./components/MapSection";
import HomePage from "./pages/HomePage";
import Dashboard from "./pages/Dashboard";
import Navbar from "./components/Navbar";

const GOOGLE_MAPS_LIBRARIES = ["places"];

export default function App() {
  return (
    <LoadScript
      googleMapsApiKey={import.meta.env.VITE_FIREBASE_API_KEY}
      libraries={GOOGLE_MAPS_LIBRARIES}
    >
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="/map" element={<MapSection />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </LoadScript>
  );
}